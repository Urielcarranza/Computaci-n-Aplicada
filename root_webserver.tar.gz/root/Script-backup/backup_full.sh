#!/bin/bash

# Verificar si se pasaron argumentos (con los parametros)
if [ $# -eq 0 ]; then
    echo "Mostrar ayuda.. -h"
    echo
    exit 1
fi

# Parceo de parametros
while getopts "o:d:h" opt; do
    case ${opt} in
        o )
            SRC_DIR=$OPTARG
            ;;
        d )
            BACKUP_DIR=$OPTARG
            ;;
        h )
            echo "Instrucciones de uso"
            echo
            echo "backup_full.sh -o directorio/de/origen -d directorio/de/destino"
            echo

            exit 0
            ;;
    esac
done

# Verificar que el directorio origen exista
if [ ! -d "${SRC_DIR}" ]; then
    echo "Error: Directorio origen ${SRC_DIR} no existe."
    exit 1
fi

# Verificar que los directorio destino exista
if [ ! -d "${BACKUP_DIR}" ]; then
    echo "Error: Directorio destino ${BACKUP_DIR} no existe."
    exit 1
fi

# Parcea la fecha actual en formato YYYYMMDD
CURRENT_DATE=$(date +"%Y%m%d")

# Función para realizar el backup
backup() {
    local src=${SRC_DIR}
    local name=$(basename ${SRC_DIR})
    local dest="${BACKUP_DIR}/${name}_bkp_${CURRENT_DATE}.tar.gz"

    # Crear el backup
    tar -czf ${dest} ${src}
    echo "Backup de ${src} completo en : ${dest}"
}

backup 

